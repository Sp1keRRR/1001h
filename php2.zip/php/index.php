﻿
<!DOCTYPE html>
<?php 
	$db = pg_connect("host=127.5.117.130 port=5432 dbname=auther user=adminbbzd2ru password=aeKdUd-AE5db")
    	or die('Could not connect: ' . pg_last_error());
	/*	
	$sql = "DROP TABLE Auther";
	$ret = pg_query($db, $sql);
	
	$sql = "CREATE TABLE Auther (
	id SERIAL PRIMARY KEY NOT NULL,
	songname TEXT NOT NULL,
	site TEXT NOT NULL,
	weather INT NOT NULL
	);";
	$ret = pg_query($db, $sql);
	//1
	$sql = "INSERT INTO Auther (songname, site, weather) VALUES ('Jordin Sparks - Walking On Snow', 'http://dnl3.best-muzon.com/dl/online/pA60dkbZO2ba6BAfM3sKeA/1446998917/music22/old2/Jordin_Sparks_-_Walking_On_Snow.mp3', 1);";
	$ret = pg_query($db, $sql);
	$sql = "INSERT INTO Auther (songname, site, weather) VALUES ('Kylie Minogue - Let it snow', 'http://dnl1.best-muzon.com/dl/online/P-Cf9T6AR6DBA1bCQ3RSMA/1446999042/songs12/2010/12/kylie-minogue-let-it-snow-%28best-muzon.com%29.mp3', 1);";
	$ret = pg_query($db, $sql);
	$sql = "INSERT INTO Auther (songname, site, weather) VALUES ('Plazma - Angel Of Snow (Radio Edit)', 'http://dnl3.best-muzon.com/dl/online/iuxNAiFGPoJL5MV80i1nTw/1446999130/songs12/2011/06/plazma-angel-of-snow-radio-edit-%28best-muzon.com%29.mp3', 1);";
	$ret = pg_query($db, $sql);
	//2
	$sql = "INSERT INTO Auther (songname, site, weather) VALUES ('Estelle - In The Rain', 'http://dnl1.best-muzon.com/dl/online/klczhjLJ9XQ4gKAnzFL-wQ/1446998781/music22/old2/Estelle_-_In_The_Rain_%28Prod._By_Johnny_Douglas%29.mp3', 2);";
	$ret = pg_query($db, $sql);
	$sql = "INSERT INTO Auther (songname, site, weather) VALUES ('Fentura - Calling On The Rain', 'http://dnl4.best-muzon.com/dl/online/7Z7MYo_j7rK1M9ayhkt3dw/1446998858/music22/old2/Fentura_-_Calling_On_The_Rain.mp3', 2);";
	$ret = pg_query($db, $sql);
	$sql = "INSERT INTO Auther (songname, site, weather) VALUES ('Eric Saade - It is gonna rain', 'http://dnl3.best-muzon.com/dl/online/Wv6II19tJztF6nRWK9_LfA/1446998876/music22/allmusic/05_10/Eric_Saade_-_Its_Gonna_Rain.mp3', 2);";
	$ret = pg_query($db, $sql);
	//3
	$sql = "INSERT INTO Auther (songname, site, weather) VALUES ('Nicole Scherzinger - Cold', 'http://dnl3.best-muzon.com/dl/online/aFJdtoNTJEIYQyVMg6ip1A/1446999808/songs12/2011/01/nicole-scherzinger-cold-%28best-muzon.com%29.mp3', 3);";
	$ret = pg_query($db, $sql);
	$sql = "INSERT INTO Auther (songname, site, weather) VALUES ('Gary Jules  -  Mad World (Cj P.A.D. Instrumental Remix 2015)', 'http://dnl6.best-muzon.com/dl/online/061eO6G_UNMwlaTkakMfkQ/1446999856/songs12/2015/03/gary-jules-mad-world-cj-p.a.d.-instrumental-remix-%28best-muzon.com%29.mp3', 3);";
	$ret = pg_query($db, $sql);
	$sql = "INSERT INTO Auther (songname, site, weather) VALUES ('30 Seconds To Mars  -  A Beautiful Lie', 'http://dnl2.best-muzon.com/dl/online/hk6f2UtDwnh_5KbPY2zOxA/1446999931/songs12/2015/09/30-seconds-to-mars-a-beautiful-lie-%28best-muzon.com%29.mp3', 3);";
	$ret = pg_query($db, $sql);
	//4
	$sql = "INSERT INTO Auther (songname, site, weather) VALUES ('Pink Floyd - Wish You Were Here', 'http://dnl5.best-muzon.com/dl/online/DNWfscbncbt8wwJMVgwhUg/1446999991/songs12/2014/05/pink-floyd-wish-you-were-here-%28best-muzon.com%29.mp3', 4);";
	$ret = pg_query($db, $sql);
	$sql = "INSERT INTO Auther (songname, site, weather) VALUES ('Daft Punk  -  Get Lucky', 'http://dnl4.best-muzon.com/dl/online/qAtHzaWOU1yS6BnLCVMIQQ/1447000035/songs12/2014/04/daft-punk-get-lucky-%28best-muzon.com%29.mp3', 4);";
	$ret = pg_query($db, $sql);
	$sql = "INSERT INTO Auther (songname, site, weather) VALUES ('Gorillaz  -  Feel Good Inc', 'http://dnl5.best-muzon.com/dl/online/th6mYY29nVWAAYdKaEtkPg/1447000103/songs12/2014/04/gorillaz-feel-good-inc-%28best-muzon.com%29.mp3', 4);";
	$ret = pg_query($db, $sql);	
	//5
	$sql = "INSERT INTO Auther (songname, site, weather) VALUES ('Blur  -  Song 2', 'http://dnl2.best-muzon.com/dl/online/spBUqri4YkIwiep_9uwLJg/1446999200/songs12/2014/05/blur-song-2-%28best-muzon.com%29.mp3', 5);";
	$ret = pg_query($db, $sql);
	$sql = "INSERT INTO Auther (songname, site, weather) VALUES ('Мумий Тролль  -  Владивосток 2000', 'http://dnl2.best-muzon.com/dl/online/p93ZjYAHOid57124iL8_XA/1446999248/songs12/2014/05/mumijj-troll-vladivostok-2000-%28best-muzon.com%29.mp3', 5);";
	$ret = pg_query($db, $sql);
	$sql = "INSERT INTO Auther (songname, site, weather) VALUES ('The Rolling Stones  -  Satisfaction', 'http://dnl4.best-muzon.com/dl/online/zFgax04EMxpZWmTgiP7CAA/1446999313/songs12/2014/04/the-rolling-stones-satisfaction-%28best-muzon.com%29.mp3', 5);";
	$ret = pg_query($db, $sql);	
	*/
	
$content = file_get_contents("https://www.gismeteo.ru/city/daily/4877/"); 
$strbegin = '<dd class=\'value m_temp c\'>'; 
$begin = strpos($content, $strbegin); 
$strend = '<span class="meas">&deg;C</span></dd>'; 
$end = strpos($content, $strend); 
$gradus = substr($content, $begin+27, $end - $begin-27); 
    
$content = file_get_contents("https://www.gismeteo.ru/city/daily/4877/"); 
$strbegin = '<dd><table><tr><td>'; 
$begin = strpos($content, $strbegin); 
$strend = '</td></tr></table></dd>'; 
$end = strpos($content, $strend); 
$pogoda = substr($content, $begin+27, $end - $begin-13); 
function check($a, $b) {
	if (strpos($a, "снег")) {
		return 1;
	}
	if (strpos($a, "дождь")) {
		return 2;
	}
	if  (((integer) $b) <= 0) {
		return 3;
	}
	if ((((integer) $b) >=0) and (((integer) $b <=10))) {
		return 4;
	}
	if  (((integer) $b) > 10) {
		return 5;
	}
}
$tip = check($pogoda, $gradus);
$schet = 0;
$sressite = array();
$sresname = array();
$ssite = array();
$sname = array();

$sql = "SELECT songname, site, weather FROM Auther WHERE weather = $tip;";
$ret = pg_query($db, $sql);

if(!$ret) { echo "Error<br>"; } 
else 
{
while($row = pg_fetch_array($ret))
{
array_push($sresname, $row["name"]);
array_push($sressite, $row["site"]);
array_push($ssite, $row["site"]);
$schet++;
}
}
shuffle($ssite);
//print_r($sressite);

for($i = 0;$i<$schet;$i++)
{
for($j = 0;$j<$schet;$j++)
{
if ($sressite[i]==$ssite[j])
{
$sname[j]=$sresname[i];
}
}
}


pg_close($db);

?>

<html>
<head>
	<meta charset="utf-8" />
	<title></title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<link href="style.css" rel="stylesheet">
</head>

<body>


<div class="wrapper">

	<header class="header">
		<div class="panel1"><p><img src="images/title.png"  height="125"  alt="Название"></p> </div>
	</header><!-- .header-->

	<main class="content">
		<center><img class="loader" img src="<?php
			switch ($tip) {
				case 1: echo "images/snow.png";
				break;
				case 2: echo "images/rain.png";
				break;
				case 3: echo "images/cold.png";
				break;
				case 4: echo "images/norm.png";
				break;
				case 5: echo "images/hot.png";
				break;
			}?>" width ="400"  id="krut" style="display:none";   height="400";></center>
	</main><!-- .content -->

</div><!-- .wrapper -->
<footer class="footer">
<div class="panel2"><font size="10" color="#008B8B" face="Century Gothic"><?php 
$content = file_get_contents("https://www.gismeteo.ru/city/daily/4877/"); 
$strbegin = '<dd class=\'value m_temp c\'>'; 
$begin = strpos($content, $strbegin); 
$strend = '<span class="meas">&deg;C</span></dd>'; 
$end = strpos($content, $strend); 
$gradus = substr($content, $begin+27, $end - $begin-27); 
echo $gradus."°C"; 
?></font> </div>

<div class="panel">
<script src="http://d3js.org/d3.v3.min.js"></script>
	<input type="image" id="prev" src="images/prev.png" height="80" alt="Prev">
	<input type="image"  src="images/play.png"    height="80" id="start"  alt="ОК">
	<input type="image" id="next" src="images/next.png" height="80"  alt="Next">
	<?php for ($i=0; $i<$schet; $i++) {
		?><audio id=<?php echo $i ?> src=<?php echo $ssite[$i]?> ></audio> <?php
	}?>
<script>
{i=0;
    document.getElementById("start").onclick = function()
    { 
	  
      var myaudio = document.getElementById(i);
      if(myaudio.paused == true)
      {
        document.getElementById(i).play();
	document.getElementById("start").src = "images/pause.png";
	document.getElementById("krut").style.display = "inline";
	document.bgColor="<?php switch ($tip) {
				case 1: echo '#6495ED';
				break;
				case 2: echo '#DDA0DD';
				break;
				case 3: echo '#AFEEEE';
				break;
				case 4: echo '#9ACD32';
				break;
				case 5: echo '#FF0000';
				break;
}
?>";

      }
      else if (myaudio.paused == false) 
      {
        document.getElementById(i).pause();
document.getElementById("start").src = "images/play.png";
      }
      }
	document.getElementById("next").onclick = function()
    {HTMLAudioElement.prototype.stop = function()
{
this.pause();
this.currentTime = 0.0;
document.getElementById("start").src = "images/pause.png";

}
	document.getElementById(i).stop();
	if ((i+1)==<?php echo $schet;?>) {
	i=0;
	}
	else {i=i+1;}
      var myaudio = document.getElementById(i);
     //if ((myaudio.next == true) && (myaudio.currentTime !=0))
      //{ 
        document.getElementById(i).play();
     // }
    }
	document.getElementById("prev").onclick = function()
    {HTMLAudioElement.prototype.stop = function()
{
this.pause();
this.currentTime = 0.0;

document.getElementById("start").src = "images/pause.png";
}
	document.getElementById(i).stop();
	if (i<=0) {
	i=<?php echo $schet; ?>-1;}
	else {i=i-1;}
      var myaudio = document.getElementById(i);
     // if ((myaudio.next == true) && (myaudio.currentTime !=0))
     // { 
        document.getElementById(i).play();
      //}
    }
	}
</script>