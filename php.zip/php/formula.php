﻿<?php
$content = file_get_contents("https://www.gismeteo.ru/city/daily/4877/"); 
$strbegin = '<dd class=\'value m_temp c\'>'; 
$begin = strpos($content, $strbegin); 
$strend = '<span class="meas">&deg;C</span></dd>'; 
$end = strpos($content, $strend); 
$gradus = substr($content, $begin+27, $end - $begin-27); 
    
$content = file_get_contents("https://www.gismeteo.ru/city/daily/4877/"); 
$strbegin = '<dd><table><tr><td>'; 
$begin = strpos($content, $strbegin); 
$strend = '</td></tr></table></dd>'; 
$end = strpos($content, $strend); 
$pogoda = substr($content, $begin+27, $end - $begin-13); 
function check($a, $b) {
	if (strpos($a, "снег")) {
		return 1;
	}
	if (strpos($a, "дождь")) {
		return 2;
	}
	if  (((int) $b) < -5) {
		return 3;
	}
	if ((((int) $b) >=-5) && (((int) $b <=10))) {
		return 4;
	}
	if  (((int) $b) > 10) {
		return 5;
	}
	
}
$tip = check($pogoda, $gradus);
?>
