﻿<?php 
   $content = file_get_contents("https://pogoda.yandex.ru/vladivostok"); 
  $strbegin = '<div class="current-weather__thermometer current-weather__thermometer_type_now">'; 
  $begin = strpos($content, $strbegin); 
  $strend = '</div></span><span class="current-weather__col current-weather__col_type_after t t_c_1">'; 
  $end = strpos($content, $strend); 
  $certificates = substr($content, $begin, $end - $begin); 
  echo $certificates;
?>