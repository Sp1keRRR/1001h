﻿
<!DOCTYPE html>
<?php 
	$db = pg_connect("host=127.9.158.2 port=5432 dbname=php user=adminhrdju4l password=xjb98GvZSTnY")
    	or die('Could not connect: ' . pg_last_error());
	
$content = file_get_contents("https://www.gismeteo.ru/city/daily/4877/"); 
$strbegin = '<dd class=\'value m_temp c\'>'; 
$begin = strpos($content, $strbegin); 
$strend = '<span class="meas">&deg;C</span></dd>'; 
$end = strpos($content, $strend); 
$gradus = substr($content, $begin+27, $end - $begin-27); 
    
$content = file_get_contents("https://www.gismeteo.ru/city/daily/4877/"); 
$strbegin = '<dd><table><tr><td>'; 
$begin = strpos($content, $strbegin); 
$strend = '</td></tr></table></dd>'; 
$end = strpos($content, $strend); 
$pogoda = substr($content, $begin+27, $end - $begin-13); 
function check($a, $b) {
	if (strpos($a, "снег")) {
		return 1;
	}
	if (strpos($a, "дождь")) {
		return 2;
	}
	if  (((int) $b) < -5) {
		return 3;
	}
	if ((((int) $b) >=-5) && (((int) $b <=10))) {
		return 4;
	}
	if  (((int) $b) > 10) {
		return 5;
	}
}
$tip = check($pogoda, $gradus);
$schet = 0;
$sressite = array();
$sresname = array();
$ssite = array();
$sname = array();

$sql = "SELECT songname, site, weather FROM Auther WHERE weather = $tip;";
$ret = pg_query($db, $sql);

if(!$ret) { echo "Error<br>"; } 
else 
{
while($row = pg_fetch_array($ret))
{
array_push($sresname, $row["name"]);
array_push($sressite, $row["site"]);
array_push($ssite, $row["site"]);
$schet++;
}
}
shuffle($ssite);
//print_r($sressite);

for($i = 0;$i<$schet;$i++)
{
for($j = 0;$j<$schet;$j++)
{
if ($sressite[i]==$ssite[j])
{
$sname[j]=$sresname[i];
}
}
}


pg_close($db);

?>

<html>
<head>
	<meta charset="utf-8" />
	<title></title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<link href="style.css" rel="stylesheet">
</head>

<body>


<div class="wrapper">

	<header class="header">
		<div class="panel1"><p><img src="images/title.png"  height="125"  alt="Название"></p> </div>
	</header><!-- .header-->

	<main class="content">
		<center><img class="loader" img src="<?php
			switch ($tip) {
				case 1: echo "images/snow.png";
				break;
				case 2: echo "images/rain.png";
				break;
				case 3: echo "images/cold.png";
				break;
				case 4: echo "images/norm.png";
				break;
				case 5: echo "images/hot.png";
				break;
			}?>" width ="400"  id="krut" style="display:none";   height="400";></center>
	</main><!-- .content -->

</div><!-- .wrapper -->
<footer class="footer">
<div class="panel2"><font size="10" color="blue" face="Century Gothic"><?php 
$content = file_get_contents("https://www.gismeteo.ru/city/daily/4877/"); 
$strbegin = '<dd class=\'value m_temp c\'>'; 
$begin = strpos($content, $strbegin); 
$strend = '<span class="meas">&deg;C</span></dd>'; 
$end = strpos($content, $strend); 
$gradus = substr($content, $begin+27, $end - $begin-27); 
echo $gradus."°C"; 
?></font> </div>

<div class="panel">
<script src="http://d3js.org/d3.v3.min.js"></script>
	<input type="image" id="prev" src="images/prev.png" height="80" alt="Prev">
	<input type="image"  src="images/play.png"    height="80" id="start"  alt="ОК">
	<input type="image" id="next" src="images/next.png" height="80"  alt="Next">
	<audio id=0 src='http://best-muzon.com/dl/online/FAvrXONrFV49q7kICuWmFQ/1446944097/songs12/2014/05/the-cure-friday-i039m-in-love-(best-muzon.com).mp3'>
</audio>
<audio id=1 src='http://best-muzon.com/dl/online/FAvrXONrFV49q7kICuWmFQ/1446944097/songs12/2014/05/the-cure-friday-i039m-in-love-(best-muzon.com).mp3'>
</audio>
<audio id=2 src='http://best-muzon.com/dl/online/FAvrXONrFV49q7kICuWmFQ/1446944097/songs12/2014/05/the-cure-friday-i039m-in-love-(best-muzon.com).mp3'>
</audio>
<script>
{i=0;
    document.getElementById("start").onclick = function()
    { 
      var myaudio = document.getElementById(i);
      if(myaudio.paused == true)
      {
        document.getElementById(i).play();
	document.getElementById("start").src = "images/pause.png";
	document.getElementById("krut").style.display = "inline";
	document.bgColor="<?php switch ($tip) {
				case 1: echo '#6495ED';
				break;
				case 2: echo '#DDA0DD';
				break;
				case 3: echo '#AFEEEE';
				break;
				case 4: echo '#9ACD32';
				break;
				case 5: echo '#FF0000';
				break;
}
?>";

      }
      else if (myaudio.paused == false) 
      {
        document.getElementById(i).pause();
document.getElementById("start").src = "images/play.png";
      }
      }
	document.getElementById("next").onclick = function()
    {HTMLAudioElement.prototype.stop = function()
{
this.pause();
this.currentTime = 0.0;
document.getElementById("start").src = "images/play.png";
}
	document.getElementById(i).stop();
	if ((i+1)==3)
	i=0;
	else i=i+1;
      var myaudio = document.getElementById(i);
      if ((myaudio.next == true) && (myaudio.currentTime !=0))
      { 
        document.getElementById(i).play();
      }
    }
	document.getElementById("prev").onclick = function()
    {HTMLAudioElement.prototype.stop = function()
{
this.pause();
this.currentTime = 0.0;

document.getElementById("start").src = "images/play.png";
}
	document.getElementById(i).stop();
	if ((i-1)==(-1))
	i=2;
	else i=i-1;
      var myaudio = document.getElementById(i);
      if ((myaudio.next == true) && (myaudio.currentTime !=0))
      { 
        document.getElementById(i).play();
      }
    }
	}
</script>