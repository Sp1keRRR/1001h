﻿<?php 
   $content = file_get_contents("https://pogoda.yandex.ru/vladivostok"); 
$convertedText = mb_convert_encoding($content, 'utf-8', mb_detect_encoding($content));
  $strbegin = 'class="current-weather__comment"'; 
  $begin = strpos($convertedText, $strbegin); 
  $strend = '</span><div class="current-weather__thermometer current-weather__thermometer_type_now">'; 
  $end = strpos($convertedText, $strend); 
  $certificates = substr($convertedText, $begin+33, $end-$begin); 
  echo $certificates;
?>